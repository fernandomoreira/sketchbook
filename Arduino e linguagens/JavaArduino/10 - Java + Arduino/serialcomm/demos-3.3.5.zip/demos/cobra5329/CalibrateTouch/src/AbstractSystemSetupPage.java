import jcontrol.ui.wombat.Container;

/**
 * Java file created by JControl/IDE
 *
 * @author timmer
 * @date 29.11.05 15:00
 *
 */
public abstract class AbstractSystemSetupPage extends Container {
               
    public AbstractSystemSetupPage() {
        super();
    }

    public AbstractSystemSetupPage(int arg0) {
        super(arg0);
    }

    public void ok() {        
    }
    
    public void cancel() {        
    }
    
    public void showPrev() {        
    }
    
    public void showNext() {       
    }
       
}
