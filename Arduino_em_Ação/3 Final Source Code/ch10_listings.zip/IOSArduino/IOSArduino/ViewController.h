//
//  ViewController.h
//  IOSArduino
//
//  Created by Martin Evans on 21/01/2012.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RscMgr.h"

#define BUFFER_LEN 1024

@interface ViewController : UIViewController <RscMgrDelegate> {
    
    RscMgr *rscMgr;
    UInt8 rxBuffer[BUFFER_LEN];
    UInt8 txBuffer[BUFFER_LEN];
    
    UISwitch *toggleSwitch;
    UISlider *moveSlider;
    UILabel *distance;
}
@property (retain, nonatomic) IBOutlet UISwitch *toggleSwitch;
@property (retain, nonatomic) IBOutlet UISlider *moveSlider;
@property (retain, nonatomic) IBOutlet UILabel *distance;


- (IBAction)toggleLED:(id)sender;
- (IBAction)brightnessLED:(id)sender;


@end
